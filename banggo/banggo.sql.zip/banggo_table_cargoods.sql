
-- --------------------------------------------------------

--
-- 表的结构 `cargoods`
--

CREATE TABLE `cargoods` (
  `id` int(11) NOT NULL,
  `gshu` text NOT NULL,
  `gprict` float NOT NULL,
  `gold` float NOT NULL,
  `gcolor` text NOT NULL,
  `gsize` text NOT NULL,
  `glist` text NOT NULL,
  `gurl` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `cargoods`
--

INSERT INTO `cargoods` (`id`, `gshu`, `gprict`, `gold`, `gcolor`, `gsize`, `glist`, `gurl`) VALUES
(20, '男士纯色一颗扣简约圆领短袖T恤【一件包邮】', 29.9, 119, '正黑', 'M:170/92A\n', '3', '../css/gImg/good (27).jpg'),
(27, '男学院风图案印花短袖T恤', 35, 188, '正黑', 'L:175/96A\n', '1', '../css/gImg/good (33).jpg'),
(22, '男植绒字母印花短袖T恤', 29.9, 119, '月蓝黑', 'XL:180/100A\n', '1', '../css/gImg/good (29).jpg'),
(59, '男植绒字母印花短袖T恤', 35, 89, '漂白', 'S:165/88A\n', '2', '../css/gImg/good (62).jpg'),
(31, '男士纯色一颗扣简约圆领短袖T恤【一件包邮】', 58, 99, '维多利亚蓝', 'M:170/92A\n', '2', '../css/gImg/good (37).jpg'),
(19, '男士夏季简约条纹衫短袖T恤【一件包邮】', 39.9, 199, '正黑', 'L:175/96A\n', '1', '../css/gImg/good (26).jpg');
