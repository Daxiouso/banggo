
-- --------------------------------------------------------

--
-- 表的结构 `yong`
--

CREATE TABLE `yong` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `yong`
--

INSERT INTO `yong` (`id`, `username`, `password`) VALUES
(1, 'laoxie', '123'),
(2, 'lemon', '123'),
(3, 'laoyao', '123');
